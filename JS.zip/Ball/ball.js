/*
* BALL.JS
*/
var counter = -1;
var windowWidth = window.innerWidth;

var ball;
var time;
var area;

var seconds = -1;
var maxSeconds = 60; // ? 
var interval;

generateStyle = function(x, y, w, h, c){
	return "top: " + y + "px; left: " + x + "px; width: " + w + "px; height: " + h + "px; background-color: " + c + "; border-radius: " + (w/2) + "px;";
}

var offset = 5;
generateX = function(){ return offset + parseInt(Math.random() * (window.innerWidth - 2*offset));  }
generateY = function(){ return offset + parseInt(Math.random() * (window.innerHeight - 2*offset)); }

generateColor = function() {
	var r = parseInt(Math.random()*256);
	var g = parseInt(Math.random()*256);
	var b = parseInt(Math.random()*256);

	return "#" + r.toString(16) + g.toString(16) + b.toString(16);
}

/** outdated
generateBallDiv = function(){
	return "<div id=\"ball\" class=\"ball\" style=\"" + generateStyle(generateX(), generateY(), 40, 40, generateColor()) + "\"></div>"
}*/

updateBallDiv = function(){
	ball.style.cssText = generateStyle(generateX(), generateY(), 40, 40, generateColor());
}

onBallClick = function(){
	/*document.getElementById('area').innerHTML = */
	updateBallDiv();
	document.getElementById('counter').style.textShadow = "0px 0px 70px white";
	window.setTimeout(function(){
			document.getElementById('counter').innerHTML = ++counter;
			document.getElementById('counter').style.textShadow = "0px 0px 20px white";
		}, 200);
}

tick = function(){
	time.style.width = (windowWidth * (1.0 - ++seconds/(maxSeconds * 1.0))) + "px";
	//time.style.backgroundColor = "hsl(0, " + (100 * (1.0 - seconds/(maxSeconds * 1.0))) + "%, 50%)";
	if(seconds >= maxSeconds) {
		window.clearInterval(interval);
		area.innerHTML = "";
		area.style.zIndex = "0";
		document.getElementById('counter').innerHTML = "END: " + counter + "<br /><button onclick=\"init()\">RESTART</button>";
		time.style.width = "0";
	}
}

start = function(){
	interval = window.setInterval(tick, 1000);
	onBallClick();
}

init = function(){
	seconds = 0;
	counter = -1;
	time = document.getElementById('time');
	area = document.getElementById('area');

	area.style.zIndex = "4";
	area.innerHTML = "<div id=\"ball\" class=\"ball\"></div>";

	ball = document.getElementById('ball');

	ball.addEventListener("click", onBallClick);

	tick();
	window.setTimeout(start, 1);
}